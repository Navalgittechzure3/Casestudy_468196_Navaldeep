export interface workout
{
    id:number;
    name:string;
    description:string;
    imagefile:string;
    weeks:number;
    days:number;
}